let starbucks=[
    {
        name: "John",
        type:"Gold"
    }
]

function displayClients(){
    console.log(starbucks[0].name);
    console.log(starbucks[1].name);
    console.log(starbucks[2].name);

    for(let i = 0; i < 2;i++){
        console.log(starbucks[i].name)
    }
    
}

