let num;
num = 5;
let saloon={
    name: "Nick's Pet Salon",
    address:{
        street: "Av. Palm",
        number: 262,
        zip: 23456,
        city: "San Diego",
        state: "California"
    },
    hours: {
        open: "9:00am",
        close: "5:00pm"
    },
    pets: []
}

//name, age, gender, breed, service, owner name, phone number
function displayInfo(){
    document.getElementById("footer-info").innerHTML=`<p> Street: ${saloon.address.street}, ZIP CODE: ${saloon.address.zip}</p>
    <p>${saloon.address.city}, ${saloon.address.state}</p>`;
}

displayInfo();


let x=0;
//constructor
//                                   Local Variables 
function Pet(petName, age, gender, breed, service,owner,phone){
        this.name = petName;
        this.age = age;
        this.gender = gender;
        this.breed = breed;
        this.service = service;
        //this.service = new Service(servA, servB, servC);
        this.owner = owner;
        this.phone = phone;
        this.id = x++;
}

/*
function Service(serviceA, serviceB, serviceC){
    this.serviceA = serviceA;
    this.serviceB = serviceB;
    this.serviceC = serviceC;
}
*/

function alert(){
    console.log(saloon.pets.length);
}

alert();

function displayPetNames(){
    for(let i =0;i<saloon.pets.length;i++)
    {
        console.log(saloon.pets[i].name);
    }
}
displayPetNames();

function checkInput(variable, id)
{
    if(variable.length < 1)
    {
        document.getElementById(id).classList.add("error");
        return false;
    }
    else
    {
        document.getElementById(id).classList.remove("error");
        return true;
    }
}



function showPetsCards(){
    document.getElementById("petList").innerHTML = '';
    for(let i = 0; i<saloon.pets.length;i++)
    {
      document.getElementById("petList").innerHTML += createCard(saloon.pets[i]);
    }
    
}

function createCard(pet){
    return `
    <div id = "${pet.id}" class="card my-card">
    <h2>${pet.name}</h2>
    <label>${pet.age}</label>
    <label>${pet.breed}</label>
    <label>${pet.gender}</label>
    <label>${pet.service}</label>
    <label>${pet.owner}</label>
    <label>${pet.phone}</label>
    <button class = "btn btn-danger btn-sm" onclick="deletePets(${pet.id})">Delete</button>
    </div>
    `;
}

function deletePets(index){
    //search the Pet 
    saloon.pets.forEach(function callback (pet,value){
        if(index===pet.id){
        console.log("I found it in the position", value);
        saloon.pets.splice(value,1);
        }
    });
    //remove the pet from the array 
    // remove the pet from the html
    console.log("removing pet", index);
    document.getElementById(index).remove();
}

function searchPets(){
    let searchString = document.getElementById("SearchInputs").value;

    saloon.pets.forEach(function callback (pet,value){
        if(searchString.toLowerCase()==pet.name.toLowerCase()){
            document.getElementById(value).classList.add("highlight");
        }
    });
}


function getInfo(){
    
    let isValid = true;
    let petName = document.getElementById("txtPetName").value;
    isValid = checkInput(petName, "txtPetName");

    let age = document.getElementById("nbAge").value;
    isValid = checkInput(age, "nbAge");

    let gender = document.getElementById("dlGender").value;
    isValid = checkInput(gender, "dlGender");

    let breed = document.getElementById("dlBreed").value;
    isValid = checkInput(breed, "dlBreed");
    
    let service = document.getElementById("dlServices").value;
    isValid = checkInput(service, "dlServices");
   
    //let serviceA = true;
    //let serviceB = true;
    //let serviceC = false;
    //let serviceA = document.getElementById("cbSA").checked;
    //let serviceB = document.getElementById("cbSB").checked;
    let owner = document.getElementById("txtOwner").value;
    isValid = checkInput(owner, "txtOwner");

    let phone = document.getElementById("txtPhone").value;
    isValid = checkInput(phone, "txtPhone");


    //we are calling the constructor here 
    if(isValid == true){
        let pet = new Pet(petName, age, gender, breed, service, owner, phone);
        saloon.pets.push(pet);
        document.getElementById("petInfo").reset();
        showPetsCards();
    }

    function init(){
        displayInfo();
        let scooby = new Pet("Scooby",50,"Male", "Dane", "Grooming", "Shaggy",555-555-5555);
        saloon.pets.push(scooby);
        showPetsCards();
    }
   
    window.onload=init;
}

    

   /*     
    function init(){
        displayInfo();
        let scooby = new Pet("Scooby",50,"Male", "Dane", "Grooming", "Shaggy",555-555-5555);
        saloon.pets.push(scooby);
        showPetsCards();
    }
   
    window.onload=init;


    //console.log(`${petName} ${age} ${gender} ${breed} ${service} ${owner} ${phone}`);
*/